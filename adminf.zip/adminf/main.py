import requests,threading
print(''' 
 ____       ____       ____   _          
|  _ \  ___|  _ \ __ _|  _ \ / \   __  __
| |_) ||_  / |_) / _` | |_) / _ \  \ \/ /
|  _ <  / /|  __/ (_| |  __/ ___ \  >  < 
|_| \_\/___|_|   \__,_|_| /_/   \_\/_/\_\

''')
fname_s=input("Enter Site File Name: ")
fadm=['admin','manager','wp-admin','user'] # You can Increase Your List
fsite=open(fname_s,"r")
found=open("Admined.txt","w")
wpf=open("wpf.txt","w")
def adminf(e):
    e=e.rstrip()
    if e[0:8]=="https://" or e[0:7]=="http://":
        url=e
    else:
        url="https://"+e
    if url[-1]=='/':
        url=url
    else:
        url=url+'/'
    for adm in fadm:
        urla=url+adm
        print('Going For url: '+urla)
        try:
            r=requests.get(urla)
            co=r.content
        except:
            print('Invalid Link: '+urla)
        if r.status_code==200:
            print('[+] Admin FOund at: '+urla)
            if 'wp-admin' in str(co):
                print('[+] Wp site: '+urla)
                wpf.write('[+]WP: '+urla+'\n')
            else: 
                found.write("[+] Admin : "+urla+'\n')
        else:
           print('[-] Admin Not Found At: '+urla) 
threads=[]
for e in fsite:
    t=threading.Thread(target=adminf,args=[e])
    t.start()
    threads.append(t)
for all in threads:
    all.join()
fsite.close()
found.close()